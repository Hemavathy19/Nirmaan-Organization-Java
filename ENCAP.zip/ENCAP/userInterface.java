package day11;

public class userInterface {
	
	public static void main(String[] args) {
		
	
	
	empoyee em  =new empoyee();
	em.setName("hema");
	
	System.out.println(em.getName());
	
	em.setId(123);
	
	System.out.println(em.getId());
	
	em.setSalary(25000);
	
	System.out.println(em.getSalary());
	
	em.setLocation("chennai");
	
	System.out.println(em.getLocation());
	
	
 
	
	}

}

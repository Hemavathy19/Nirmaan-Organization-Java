package day11;

public class empoyee {
	
	private String name;
	private int id;
	private double salary;
	private String location;
	
	public void setName(String empoyeeName) {
		name=empoyeeName;}
		
		public String getName() {
			return name;
			
			
		}
		
		public void setId(int empoyeeId) {
			id =empoyeeId;
			
		}
		
		public int getId() {
			return id;
		}
		
		public void setSalary(double empoyeeSalary) {
			salary= empoyeeSalary;
		}
		
		public double getSalary() {
			return salary;
		}
		
		public void setLocation(String empoyeeLocation) {
			location=empoyeeLocation;
			
		}
		
		public String getLocation() {
			return location;
		}
		
	}
	
	

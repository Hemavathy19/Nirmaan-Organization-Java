package libraryMangementSystem;


import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class UserInterface {

	public static void main(String[] args) {
		List<Library> ll = new LinkedList<Library>();
		Scanner sc = new Scanner(System.in);
		Library std = new Library();

		LibraryService service = new LibraryService();
		// CRUD 
		
		
		while (true) {
			System.out.println("Enter your Choice");
			System.out.println("1 for post book in library ");
			System.out.println("2 for get All the BOOKS");
			System.out.println("3 for get BOOKS By Id ");
			System.out.println(("4 for put BOOKS")); // update Student
			System.out.println("5 for delete BOOKS By Id");
			int key = sc.nextInt();

			if (key == 1) {

				ll.add(service.addStudent());

			} else if (key == 2) {
				service.getStudents(ll);

			} else if (key == 3) {

				Library existStudent = service.getStudentById(ll);
				if (existStudent != null) {
					System.out.println(existStudent);
				} else {
					System.out.println("Book Not Found");
				}

			} else if (key == 4) {
				ll = service.putStudent(ll);

			} else if (key == 5) {
				ll = service.deleteStudent(ll);
			}

		}

	}

}
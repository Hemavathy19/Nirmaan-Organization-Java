package library;

import java.util.ArrayList;
import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		ArrayList<Books> al = new ArrayList<Books>();
		Scanner sc = new Scanner(System.in);
		
		BookService service = new BookService();
		
		Books b = new Books();
		while(true) {
			System.out.println("ENter your choice \n 1 for add book \n 2 for show book \n  3 for search book by id");
			
			int key = sc.nextInt();
			
			if (key ==1){
				al.add(service.addBook());
				
				
			}
			else if (key == 2) {
				service.getBooks(al);
				
			}
			else if (key==3) {
				System.out.println("Enter the book id :");
				int BookId =sc.nextInt();
				System.out.println(service.getBookId(BookId,al));
			}
		}
		
	}

}

package library;

import java.util.ArrayList;
import java.util.Scanner;

public class BookService {
	 Scanner sc = new Scanner(System.in);
	 
	 public Books addBook() {
		 System.out.println("Enter book ID :");
		 int BookId = sc.nextInt();
		 sc.nextLine();
		 
		 System.out.println("Enter the book name : ");
		 String BookName = sc.nextLine();
		 
		 System.out.println("Enter the author :");
		 String BookAuthor = sc.nextLine();
		 
		 System.out.println("Enter the price of the book :");
		 double price = sc.nextDouble();
		 
		 return new Books (BookId ,BookName, BookAuthor ,price);
		 
		 
		 }
	 public void getBooks(ArrayList<Books> books) {
		 System.out.println(books);
	 }
	 
	 public Books getBookId(int BookId, ArrayList<Books> Books) {
		 for (Books b : Books) { 
			 if (b.getBookId()==BookId) {
				 return b;
			 }
			 
		 }
		 return null;
		 
	 }
	 
	 

}
